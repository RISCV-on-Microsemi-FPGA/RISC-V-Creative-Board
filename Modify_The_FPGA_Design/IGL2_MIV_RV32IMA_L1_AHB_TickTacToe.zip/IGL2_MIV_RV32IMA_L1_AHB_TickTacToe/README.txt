================================================================================
        RISCV_BaseDesign for the RISC-V Creative Developement Board
================================================================================

This design is targeted at the RISC-V Creative Developement Board. It uses
the CoreRISCV_AXI4 as its soft processor on M2GL025 FPGA.

--------------------------------------------------------------------------------
    Memory map
--------------------------------------------------------------------------------

0x60000000: NVM Flash memory containing the RISC-V processor reset vector and
            application code.

0x70001000: CoreUART
0x70002000: CoreGPIO inputs
0x70003000: CoreTimer0
0x70004000: CoreTimer1
0x70005000: CoreGPIO outputs
0x70006000: CoreSPI

0x80000000: DDR memory.

